<!DOCTYPE html>
<html lang="en">

<head>
    <title>Login</title>
    <link rel="stylesheet" type="text/css" href="loginPage.css">
</head>

<body>
    <div class="wrapper fadeInDown">
        <div id="formContent">
            <!-- Tabs Titles -->
            <h2 class="active">ورود</h2>
            <a class="inactive underlineHover" , href="index1.php">ثبت نام</a>

            <!-- Icon -->
            <div class="fadeIn first">
                <img src="user.png" id="icon" alt="User Icon" />
            </div>

            <!-- Login Form -->
            <form action="login.php" method="post">
                <?php if (isset($_GET['error']))
                {
                    ?>
                    <p class="error"><?php echo $_GET['error']; ?></p>
                    <?php
                }
                ?>
                <input type="text" id="login" class="fadeIn second" name="uname" placeholder="نام کاربری">
                <input type="text" id="password" class="fadeIn third" name="password" placeholder="رمز">
                <input type="submit" class="fadeIn fourth" value="ورود">
            </form>

            <!-- Remind Passowrd -->
            <div id="formFooter">
                <a class="underlineHover" href="#">فراموشی رمز</a>
            </div>

        </div>
    </div>
</body>

</html>