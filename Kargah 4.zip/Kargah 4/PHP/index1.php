<!DOCTYPE html>
<html lang="en">

<head>
    <title>Login</title>
    <link rel="stylesheet" type="text/css" href="loginPage.css">
</head>

<body>
    <div class="wrapper fadeInDown">
        <div id="formContent">
            <!-- Tabs Titles -->
            <h2 class="inactive underlineHover">ورود</h2>
            <h2 class="active">ثبت نام</h2>

            <!-- Icon -->
            <div class="fadeIn first">
                <img src="user.png" id="icon" alt="User Icon" />
            </div>

            <!-- Login Form -->
            <form action= "signIn.php" method = "POST">
                <?php if (isset($_GET['error']))
                {
                    ?>
                    <p class="error"><?php echo $_GET['error']; ?></p>
                    <?php
                }
                ?>
                <input type="text" id="login" class="fadeIn second" name="uname" placeholder="نام کاربری">
                <input type="text" id="password" class="fadeIn third" name="password" placeholder="رمز">
                <input type="submit" class="fadeIn fourth" value="ثبت">
            </form>
        </div>
    </div>
</body>

</html>