<?php

$showAlert = false;  
$showError = false;  
$exists=false; 
    
if($_SERVER["REQUEST_METHOD"] == "POST") { 
      
    // Include file which makes the 
    // Database Connection. 
    include 'dbconnect.php';    
    
    $username = $_POST["uname"];  
    $password = $_POST["password"];  
            
    
    $sql = "Select * from users where username='$username'"; 
    
    $result = mysqli_query($conn, $sql); 
    
    $num = mysqli_num_rows($result);  
    
    // This sql query is use to check if 
    // the username is already present  
    // or not in our Database 
    if($num == 0) { 
        if(($password == $cpassword) && $exists==false) { 
    
            $hash = password_hash($password,  
                                PASSWORD_DEFAULT); 
                
            // Password Hashing is used here.  
            $sql = "INSERT INTO `users` ( `unname`,  
                `password`, `date`) VALUES ('$username',  
                '$hash', current_timestamp())"; 
    
            $result = mysqli_query($conn, $sql); 
    
            if ($result) { 
                $showAlert = true;  
            } 
        }  
        else {  
            $showError = "Passwords do not match";  
        }       
    }// end if  
    
   if($num>0)  
   { 
      $exists="Username not available";  
   }  
    
}//end if    
    
?> 
 /*
$pdo = require_once("db_conn.inc");

$sql = "SELECT * FROM test_db.users";// WHERE user_name=$uname AND password=$pass";

$statement = $pdo -> query($sql);
$row = $statement -> fetchall(PDO::FETCH_ASSOC);

   if (isset($_POST['uname']) && isset($_POST['password']))
   {
       function validate($data)
       {
           $data = trim($data);
           $data = stripslashes($data);
           $data = htmlspecialchars($data);
           return $data;
       }
   }
   
   $uname = validate($_POST['uname']);
   $pass = validate($_POST['password']);

    if ($row[0]['user_name'] == $uname && $row[0]['password'] == $pass)
    {
        echo "Logged in!";

        setcookie('user_name' , $row[0]['user_name'] , time() + 8600);
        setcookie('id' , $row[0]['id'] , time() + 8600);

       header("Location: home.php");
       exit();
    }
    else
    {
        header("Location: index.php?error=نام کاربری یا رمز عبور اشتباه می باشد");
        exit();
    }*/