<?php

setcookie('user_name' , $row[0]['user_name'] , time() - 8600);
setcookie('id' , $row[0]['id'] , time() - 8600);



header("Location: proj3.php");