<?php

$pdo = require_once("db_conn.inc");

$sql = "SELECT * FROM test_db.users";// WHERE user_name=$uname AND password=$pass";

$statement = $pdo -> query($sql);
$row = $statement -> fetchall(PDO::FETCH_ASSOC);

   if (isset($_POST['uname']) && isset($_POST['password']))
   {
       function validate($data)
       {
           $data = trim($data);
           $data = stripslashes($data);
           $data = htmlspecialchars($data);
           return $data;
       }
   }
   
   $uname = validate($_POST['uname']);
   $pass = validate($_POST['password']);

    if ($row[0]['user_name'] == $uname && $row[0]['password'] == $pass)
    {
        echo "Logged in!";

        setcookie('user_name' , $row[0]['user_name'] , time() + 8600);
        setcookie('id' , $row[0]['id'] , time() + 8600);

       header("Location: home.php");
       exit();
    }
    else
    {
        header("Location: index.php?error=نام کاربری یا رمز عبور اشتباه می باشد");
        exit();
    }