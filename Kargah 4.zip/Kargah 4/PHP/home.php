<?php
session_start();

if (isset($SESSION['id']) && isset($SESSION['user_name']))
{
    ?>

    <!DOCTYPE html>
    <html>
    <head>
        <title>HOME</title>
        <link rel="stylesheet" type="text/css" href="stylecss">
    </head>
    <body>
        <h1>Hello, <?php echo $_SESSION['user_name']; ?></h1>
        <a href="logout.php">Logout</a>
    </body>
    </html>

    <?php
}
else
{
    header("Location: proj3.php");
    exit();
}
?>