<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>project 3</title>
    <link rel="stylesheet" href="proj3.css">
</head>

<body>
    <div class="container">
        <header id="header">
            <img src="Logo.webp" width="120px" id="logo">
            <h1 id="prototype"><strong>وبلاگ برنامه نویسی</strong></h1>
            <h2 id="underprototype">وبلاگ شخصی</h2>
            <?php
            if (isset($_COOKIE['user_name']))
            {
                echo "<a id='enter' href='logout.php'>خروج</a>";
            }
            else{
                echo "<a id='enter' href='index.php'> ورود یا ثبت نام</a>";
            }
            ?>
        </header>

        <nav id="navigation">
            <ul id="nav">
                <a href="#">
                    <li class="list">خانه</li>
                </a>
                <a href="#">
                    <li class="list">محصولات</li>
                </a>
                <a href="#">
                    <li class="list">آخرین مطلب</li>
                </a>
                <a href="#">
                    <li class="list">درباره</li>
                </a>
                <a href="#">
                    <li class="list">تماس</li>
                </a>
            </ul>
        </nav>

        <aside id="sidebar">
            <div id="parts">
                <p id="part1">دسته بندی ها</p>
                <ul>
                    <a href="#" class="link">
                        <li class="list2">فرانت اند</li>
                    </a>
                    <a href="#" class="link">
                        <li class="list2">بک اند</li>
                    </a>
                    <a href="#" class="link">
                        <li class="list2">دیتا بیس</li>
                    </a>
                    <a href="#" class="link">
                        <li class="list2">گرافیک</li>
                    </a>
                </ul>
            </div>

            <div id="news">
                <p id="newstitle">خبرنامه</p>
                <form>
                    <p style="text-align: center; font-size: 17px; padding: 5px;">برای عضویت در خبرنامه سایت</p>
                    <p style="text-align: center; font-size: 17px;">ایمیل خود را وارد کنید:</p>
                    <input type="email" id="inp" placeholder="ایمیل"> <br>
                    <input type="submit" style="cursor: pointer;" name="email" value="عضویت" id="reg">
                </form>
            </div>
        </aside>
        <section id="section">
            <article style="width: 780px; height: 380px; background-color: white; position: relative;">
                <p style="font-size: 36px; padding: 20px;"><strong>یادگیری پایتون</strong></p>
                <hr style="border: 2px dashed;">
                <img src="Python.webp" width="300px" height="200px" style="float: right; margin-right: 10px;
                border: 5px double; border-color: yellow;">

                <p class="matn">در این آموزش قصد داریم پایتون را از پایه آموزش دهیم و سعی می کنیم تمام مطالب مقدماتی
                    لازم برای برنامه نویسی با پایتون را پوشش دهیم. چرا که برای انجام هر کاری با پایتون، نیازمند آشنایی
                    با دانش مقدماتی و نحوه برنامه نویسی با پایتون هستیم. مخاطبان این آموزش نیاز به دانش قبلی از پایتون
                    ندارند و سعی می شود تمام مطالب لازم در همین آموزش بیان شود. در پایان این آموزش شما قادر خواهید بود
                    به راحتی با پایتون برنامه نویسی کنید و مسیر مورد علاقه خود را برای ادامه کار با پایتون انتخاب کنید.
                    پایتون (Python)، یک زبان قدرتمند، سطح بالا و بسیار محبوب برنامه نویسی است. این زبان در سال ۲۰۱۹
                    همواره در بین سه زبان محبوب برنامه نویسی قرار دارد. این زبان قدرتمند برنامه نویسی در زمینه های
                    مختلفی چون: توسعه وب، توسعه نرم افزار، ریاضیات، System Scripting و… مورد استفاده قرار می گیرد.
                </p>

                <p class="matnfooter">منتشر شده در 18 اردیبهشت 1399</p>
                <a href="#" class="edamematlab">ادامه مطلب</a>
            </article>

            <article style="width: 780px; height: 380px; background-color: white; position: relative; top: 50px;">
                <p style="font-size: 36px; padding: 20px;"><strong>یادگیری سی پلاس پلاس</strong></p>
                <hr style="border: 2px dashed;">

                <img src="Cpp.jpg" width="300px" height="200px" style="float: right; margin-right: 10px;
                border: 5px double; border-color: yellow;">

                <p class="matn">++C یک برنامه همه منظوره و عمومی است که هم اکنون در سطح وسیعی از علم کامپیوتر استفاده می
                    شود و مفاهیم شی گرایی وراثت و چندریختی را بیان می کند. تمام نرم افزارهایی که به صورت روزمره در
                    ویندوز با آن ها کار می کنیم توسط زبان مادر سی و سی پلاس پلاس نوشته شده اند و در صنعت خودروسازی،
                    فضایی، معماری، بانکی، کنسول بازی و ... کاربرد دارند. هدف این فرادرس آموزشC++ ‎ در دو بخش معرفی
                    دستورات و ساختمان داده و بیان مفاهیم شی گرایی است.
                    ادگیری یک زبان برنامه نویسی دید ما را به علم کامپیوتر بسیار گسترده تر می کند. از طرفی برنامه نویسی
                    نحوه فکر کردن را به ما می آموزد. عمومیت زبان C++‎ در میان زبان های برنامه نویسی بسیار بالا است و می
                    تواند به عنوان اولین زبان نیز یاد گرفته شود و به پیش نیاز دیگر احتیاج نباشد.
                </p>

                <p class="matnfooter">منتشر شده در 23 خرداد 1400
                <p>
                    <a href="#" class="edamematlab">ادامه مطلب</a>
            </article>

            <article style="width: 780px; height: 380px; background-color: white; position: relative; top:100px;">

                <p style="font-size: 36px; padding: 20px;"><strong>یادگیری فلاتر</strong></p>
                <hr style="border: 2px dashed;">

                <img src="Flutter.png" width="300px" height="200px" style="float: right; margin-right: 10px;
                border: 5px double; border-color: yellow;">

                <p class="matn">فلاتر (flutter) چیست؟ در فراز و فرود فناوری‌های جدید، دنیای تکنولوژی با سرعت فزاینده‌ای
                    در حال تحول است. با دقت در عرصه توسعه موبایل، فناوری جدید و کاربردی به نام Flutter توجه را جلب
                    می‌کند. کسب‌و‌کارها و توسعه‌دهندگان برنامه‌های کاربردی چگونه می‌توانند از Flutter در پروژه‌های توسعه
                    موبایل استفاده کنند؟ در مطلب «فلاتر چیست؟ | به زبان ساده + نمونه پروژه»، سعی شده است تمامی موضوعات
                    مهم و کاربردی در مورد Flutter گردآوری شود تا علاقه‌مندان بتوانند دید و درک کاملی نسبت به فلاتر و همه
                    سؤالات پیرامون آن به دست آورند. به خصوص، منابع مختلف آموزش Flutter و یادگیری آن به صورت فیلم آموزش
                    فلاتر و همچنین مطالب آموزش Flutter در این مقاله به صورت جامع معرفی شده‌اند.</p>

                <p class="matnfooter">منتشر شده در 1 خرداد 1401</p>
                <a href="#" class="edamematlab">ادامه مطلب</a>
            </article>
        </section>
        <footer id="footer">
            <p>تمامی حقوق این سایت برای مالک محفوظ می باشد</p>
        </footer>
    </div>
</body>

</html>