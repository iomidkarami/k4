<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="loginPage.css">
</head>

<body>
    <div class="wrapper fadeInDown">
        <div id="formContent">
            <!-- Tabs Titles -->
            <h2 class="active">ورود</h2>
            <h2 class="inactive underlineHover">ثبت نام</h2>

            <!-- Icon -->
            <div class="fadeIn first">
                <img src="user.png" id="icon" alt="User Icon" />
            </div>

            <!-- Login Form -->
            <form action="login.php" method="post">
                <?php include 'index.php';?>
                <input type="text" id="login" class="fadeIn second" name="login" placeholder="نام کاربری">
                <input type="text" id="password" class="fadeIn third" name="login" placeholder="رمز">
                <input type="text" id="password" class="fadeIn third" name="login" placeholder="رمز">
                <input type="submit" class="fadeIn fourth" value="ورود">
            </form>

            <!-- Remind Passowrd -->
            <div id="formFooter">
                <a class="underlineHover" href="#">فراموشی رمز</a>
            </div>

        </div>
    </div>
</body>

</html>